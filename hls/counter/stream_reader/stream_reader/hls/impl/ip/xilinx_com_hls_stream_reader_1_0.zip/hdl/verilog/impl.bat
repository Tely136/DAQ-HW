: ==============================================================
: Vitis HLS - High-Level Synthesis from C, C++ and OpenCL v2026.1 (64-bit)
: Tool Version Limit: 2026.06
: Copyright 1986-2022 Xilinx, Inc. All Rights Reserved.
: Copyright 2022-2026 Advanced Micro Devices, Inc. All Rights Reserved.
: 
: ==============================================================
C:/AMDDesignTools/2026.1/Vivado/bin/vivado  -mode batch -source run_vivado.tcl || exit $?


